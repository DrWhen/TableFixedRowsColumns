//
//  CollectionViewCell.swift
//  TableRowColumn
//
//  Created by Christopher Dyer on 06.08.19.
//  Copyright © 2019 Christopher Dyer. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell
{
    @IBOutlet weak var cVLabel: UILabel!
    
    override func awakeFromNib()
    { super.awakeFromNib() }
}
