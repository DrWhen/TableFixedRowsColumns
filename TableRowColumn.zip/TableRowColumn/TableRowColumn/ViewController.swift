//
//  ViewController.swift
//  TableRowColumn
//
//  Created by Christopher Dyer on 06.08.19.
//  Copyright © 2019 Christopher Dyer. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
{
    @IBOutlet weak var cView: UICollectionView!
    @IBOutlet weak var CViewFlowLayout: UICollectionViewFlowLayout!
    
    var collectionContents = MyData()
    var currentContents: [MyLabel] = []
    
    let rowHeight: CGFloat = 30
    let numberOfColumns: CGFloat = 5
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.cView.dataSource = self
        self.cView.delegate = self
        
        self.cView.register(UINib.init(nibName: "CollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "CollectionViewCell")
        
        currentContents = collectionContents.labels
        self.cView.reloadData()
    }

    // ??? do any of these methods manage rotation of device for all devices???
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        
        guard previousTraitCollection != nil else {
            return
        }
        cView.collectionViewLayout.invalidateLayout()
        cView.reloadData()
    }
    
//    override func willTransition(to state: UITableViewCell.StateMask) {
//        super.willTransition(to: state)
//        cView.collectionViewLayout.invalidateLayout()
//    }
    
    
    func willRotateToInterfaceOrientation(toInterfaceOrientation: UIInterfaceOrientation, duration: TimeInterval) {
        cView.collectionViewLayout.invalidateLayout()
        cView.reloadData()
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int
    { return 1 }
    
    func collectionView( _ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    { return currentContents.count }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as! CollectionViewCell
        
        let settings = currentContents[indexPath.item]
        cell.cVLabel.text = settings.text
        
        cell.contentView.layer.cornerRadius = 5
        cell.contentView.layer.borderWidth = 0.5
        
        cell.contentView.layer.borderColor = UIColor.gray.cgColor
        cell.contentView.layer.masksToBounds = true
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets
    { return UIEdgeInsets(top: 0, left: 0, bottom: 10, right: 0) }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat
    { return 0 }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat
    { return 0.5 }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        var columnPortion = CGFloat()
        let columnNumber = indexPath.item % 5
        switch columnNumber {
        case 0:
            columnPortion = 0.6
        case 1:
            columnPortion = 0.3
        case 2:
            columnPortion = 1
        case 3:
            columnPortion = 1.4
        case 4:
            columnPortion = 1.7
        default:
            columnPortion = 1
        }
        
        // https://stackoverflow.com/questions/54915227/uicollectionview-remove-space-between-cells-with-7-items-per-row
        var cellWidth = CGFloat()
        let availableWidth = collectionView.bounds.size.width
        print("available width", availableWidth)
        
        let minimumWidth = floor(availableWidth / numberOfColumns)
        print("minmum width", minimumWidth)
        
        cellWidth = minimumWidth * columnPortion - 1
        print("cell width", cellWidth)
        
        return CGSize(width: cellWidth, height: rowHeight).xx_rounded()
    }
}

extension CGFloat
{
    func xx_rounded(_ rule: FloatingPointRoundingRule = .down, toDecimals decimals: Int = 0) -> CGFloat
    {
        let multiplier = CGFloat(10 ^ decimals)
        return (self * multiplier).rounded(.down) / multiplier
    }
}

extension CGSize
{
    func xx_rounded(rule: FloatingPointRoundingRule = .down, toDecimals: Int = 0) -> CGSize
    { return CGSize(width: width.xx_rounded(rule, toDecimals: toDecimals),
                    height: height.xx_rounded(rule, toDecimals: toDecimals)) }
}
