//
//  EndingsCollectionModel.swift
//  DeutschGramma
//
//  Created by Christopher Dyer on 25.04.19.
//  Copyright © 2019 Christopher Dyer. All rights reserved.
//

import Foundation
import UIKit

//protocol Content
//{
//    var heading: String { get }
//    var subHeading: String? { get }
//}
//}

struct MyLabel
{ let text: String }

class MyData
{
    let labels: [MyLabel]
    
    init()
    {
        self.labels = [
            MyLabel(text: "Col1 Row1"),
            MyLabel(text: "Col2 Row1"),
            MyLabel(text: "Col3 Row1"),
            MyLabel(text: "Col4 Row1"),
            MyLabel(text: "Col5 Row1"),
            MyLabel(text: "Col1 Row2"),
            MyLabel(text: "Col2 Row2"),
            MyLabel(text: "Col3 Row2"),
            MyLabel(text: "Col4 Row2"),
            MyLabel(text: "Col5 Row2"),
            MyLabel(text: "Col1 Row3"),
            MyLabel(text: "Col2 Row3"),
            MyLabel(text: "Col3 Row3"),
            MyLabel(text: "Col4 Row3"),
            MyLabel(text: "Col5 Row3"),
            MyLabel(text: "Col1 Row4"),
            MyLabel(text: "Col2 Row4"),
            MyLabel(text: "Col3 Row4"),
            MyLabel(text: "Col4 Row4"),
            MyLabel(text: "Col5 Row4"),
        ]
    }
}
